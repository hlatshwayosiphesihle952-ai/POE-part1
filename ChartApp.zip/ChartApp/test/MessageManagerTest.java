import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

public class MessageManagerTest {


    @Test
    void testSentMessagesArrayPopulated() {
        assertEquals(2, MessageManager.sentMessages.size());
        assertTrue(MessageManager.sentMessages.contains("Did you get the cake?"));
        assertTrue(MessageManager.sentMessages.contains("It is dinner time!"));
    }

    @Test
    void testLongestStoredMessage() {
        String longest = "";
        for (String msg : MessageManager.storedMessages) {
            if (msg.length() > longest.length()) longest = msg;
        }
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    @Test
    void testSearchByMessageID() {
        String id = "08388884567";
        assertTrue(MessageManager.messageIDs.containsKey(id));
        assertEquals("It is dinner time!", MessageManager.messageIDs.get(id));
    }

    @Test
    void testSearchByRecipient() {
        String recipient = "+27838884567";
        List<String> results = new ArrayList<>();
        for (String msg : MessageManager.storedMessages) {
            results.add(msg);
        }
        assertTrue(results.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(results.contains("Ok, I am leaving without you."));
    }

    @Test
    void testDeleteByHash() {
        String hash = "HASH1";
        assertTrue(MessageManager.messageHashes.containsKey(hash));
        String deleted = MessageManager.messageHashes.remove(hash);
        assertEquals("Where are you? You are late! I have asked you to be on time.", deleted);
        assertFalse(MessageManager.messageHashes.containsKey(hash));
    }

    @Test
    void testReportGeneration() {
        StringBuilder report = new StringBuilder();
        for (Map.Entry<String, String> entry : MessageManager.messageHashes.entrySet()) {
            report.append("Hash: ").append(entry.getKey())
                  .append(" | Message: ").append(entry.getValue()).append("\n");
        }
        assertTrue(report.toString().contains("HASH2"));
        assertTrue(report.toString().contains("Ok, I am leaving without you."));
    }
}


