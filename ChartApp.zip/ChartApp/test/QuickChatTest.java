import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class QuickChatTest {

    @Test
    public void testMessageLengthSuccess() {
        String message = "Hello, this is a short message.";
        assertTrue(message.length() <= 250, "Message ready to send.");
    }

    @Test
    public void testMessageLengthFailure() {
        String message = "A".repeat(300); // too long
        assertTrue(message.length() > 250,
            "Message exceeds 250 characters by " + (message.length() - 250));
    }

    @Test
    public void testRecipientFormatSuccess() {
        String recipient = "+27718693002";
        assertTrue(recipient.startsWith("+") && recipient.length() <= 10,
            "Cell phone number successfully captured.");
    }

    @Test
    public void testRecipientFormatFailure() {
        String recipient = "08575975889";
        assertFalse(recipient.startsWith("+"),
            "Cell phone number is incorrectly formatted or does not contain an international code.");
    }

    @Test
    public void testMessageHash() {
        String messageID = "0012345678";
        String message = "Hi Mike tonight";
        String hash = QuickChat.generateMessageHash(messageID, 0, message);
        assertEquals("00:0:HITONIGHT", hash);
    }
}


