import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {
            Login login = new Login();
            
            System.out.print("Enter username: ");
            String username = input.nextLine();
            
            System.out.print("Enter password: ");
            String password = input.nextLine();
            
            System.out.print("Enter cell phone (+27...): ");
            String cell = input.nextLine();
            
            
            String registrationMessage = login.registerUser(username, password, cell);
            System.out.println(registrationMessage);
            
            System.out.print("Enter username to login: ");
            String loginUser = input.nextLine();
            
            System.out.print("Enter password to login: ");
            String loginPass = input.nextLine();
            
            boolean status = login.loginUser(loginUser, loginPass);
            
            System.out.println(login.returnLoginStatus(status, "John", "Doe"));
        }
    }

    private static class Login {

        public Login() {
        }

        private String registerUser(String username, String password, String cell) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private boolean returnLoginStatus(boolean status, String john, String doe) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private boolean loginUser(String loginUser, String loginPass) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

      




    }
}
  