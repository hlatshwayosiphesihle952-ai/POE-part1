import java.util.*;

public class QuickChat {
    private static int numMessagesSent = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to QuickChat!");

        // Login simulation
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (!login(username, password)) {
            System.out.println("Login failed. Exiting...");
            return;
        }

        System.out.print("How many messages would you like to send? ");
        int totalMessages = Integer.parseInt(scanner.nextLine());

        int choice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1) Send Message");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    sendMessage(totalMessages);
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 3);
    }

    private static boolean login(String user, String pass) {
        // Simple login check (replace with real validation later)
        return user.equals("admin") && pass.equals("1234");
    }

    private static void sendMessage(int totalMessages) {
        if (numMessagesSent >= totalMessages) {
            System.out.println("Message limit reached.");
            return;
        }

        System.out.print("Enter recipient number: ");
        String recipient = scanner.nextLine();

        System.out.print("Enter message: ");
        String message = scanner.nextLine();

        if (message.length() > 250) {
            System.out.println("Please enter a message of less than 250 characters.");
            return;
        }

        numMessagesSent++;
        String messageID = generateMessageID();
        String messageHash = generateMessageHash(messageID, numMessagesSent, message);

        System.out.println("Message successfully sent.");
        System.out.println("Message ID: " + messageID);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + message);
        System.out.println("Total messages sent: " + numMessagesSent);
    }

    private static String generateMessageID() {
        Random rand = new Random();
        int id = 1000000000 + rand.nextInt(900000000);
        return String.valueOf(id);
    }

    static String generateMessageHash(String messageID, int num, String message) {
        String[] words = message.split(" ");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return messageID.substring(0, 2) + ":" + num + ":" + firstWord + lastWord;
    }
}
