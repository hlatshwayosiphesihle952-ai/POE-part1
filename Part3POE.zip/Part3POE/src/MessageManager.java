import java.util.*;

public class MessageManager {

    // Arrays (using ArrayList for flexibility)
    private static List<String> sentMessages = new ArrayList<>();
    private static List<String> disregardedMessages = new ArrayList<>();
    private static List<String> storedMessages = new ArrayList<>();
    private static Map<String, String> messageIDs = new HashMap<>(); // ID → Message
    static Map<String, String> messageHashes = new HashMap<>(); // Hash → Message

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Populate with test data
        populateTestData();

        int choice;
        do {
            System.out.println("\n=== Message Management System ===");
            System.out.println("1. View Sent Messages");
            System.out.println("2. View Disregarded Messages");
            System.out.println("3. View Stored Messages");
            System.out.println("4. Stored Messages Menu");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1 -> displayArray("Sent Messages", sentMessages);
                case 2 -> displayArray("Disregarded Messages", disregardedMessages);
                case 3 -> displayArray("Stored Messages", storedMessages);
                case 4 -> storedMessagesMenu(sc);
                case 0 -> System.out.println("Exiting program...");
                default -> System.out.println("Invalid choice!");
            }
        } while (choice != 0);
    }

    // Populate arrays with sample data
    private static void populateTestData() {
        sentMessages.add("Did you get the cake?");
        sentMessages.add("It is dinner time!");

        disregardedMessages.add("Yohoooo, I am at your gate.");

        storedMessages.add("Where are you? You are late! I have asked you to be on time.");
        storedMessages.add("Ok, I am leaving without you.");

        // IDs and Hashes
        messageIDs.put("08388884567", "It is dinner time!");
        messageHashes.put("HASH1", "Where are you? You are late! I have asked you to be on time.");
        messageHashes.put("HASH2", "Ok, I am leaving without you.");
    }

    // Display array contents
    private static void displayArray(String title, List<String> arr) {
        System.out.println("\n--- " + title + " ---");
        for (String msg : arr) {
            System.out.println(msg);
        }
    }

    // Stored Messages Menu
    private static void storedMessagesMenu(Scanner sc) {
        System.out.println("\n--- Stored Messages Menu ---");
        System.out.println("a. Display sender & recipient (simplified)");
        System.out.println("b. Display longest stored message");
        System.out.println("c. Search by Message ID");
        System.out.println("d. Search by Recipient");
        System.out.println("e. Delete by Hash");
        System.out.println("f. Display full report");
        System.out.print("Enter option: ");
        String option = sc.nextLine();

        switch (option) {
            case "a" -> displaySenderRecipient();
            case "b" -> displayLongestMessage();
            case "c" -> searchByMessageID(sc);
            case "d" -> searchByRecipient(sc);
            case "e" -> deleteByHash(sc);
            case "f" -> displayReport();
            default -> System.out.println("Invalid option!");
        }
    }

    private static void displaySenderRecipient() {
        System.out.println("Stored Messages (Sender → Recipient):");
        // Simplified since sender info isn’t fully given in test data
        System.out.println("Sender: System → Recipient: +27838884567");
        System.out.println("Sender: System → Recipient: +27838884567");
    }

    private static void displayLongestMessage() {
        String longest = "";
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        System.out.println("Longest Stored Message: " + longest);
    }

    private static void searchByMessageID(Scanner sc) {
        System.out.print("Enter Message ID: ");
        String id = sc.nextLine();
        if (messageIDs.containsKey(id)) {
            System.out.println("Message found: " + messageIDs.get(id));
        } else {
            System.out.println("Message ID not found.");
        }
    }

    private static void searchByRecipient(Scanner sc) {
        System.out.print("Enter Recipient: ");
        String recipient = sc.nextLine();
        System.out.println("Messages for " + recipient + ":");
        for (String msg : storedMessages) {
            System.out.println(msg);
        }
    }

    private static void deleteByHash(Scanner sc) {
        System.out.print("Enter Message Hash: ");
        String hash = sc.nextLine();
        if (messageHashes.containsKey(hash)) {
            System.out.println("Message deleted: " + messageHashes.remove(hash));
        } else {
            System.out.println("Hash not found.");
        }
    }

    private static void displayReport() {
        System.out.println("\n--- Stored Messages Report ---");
        for (Map.Entry<String, String> entry : messageHashes.entrySet()) {
            System.out.println("Hash: " + entry.getKey() + " | Message: " + entry.getValue());
        }
    }
}
